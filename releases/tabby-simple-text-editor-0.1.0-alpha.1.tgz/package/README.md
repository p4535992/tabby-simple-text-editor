# tabby-simple-text-editor v0.1.0-alpha.1

Test prerelease. Open an SSH session in Tabby, then use Ctrl+Alt+E or the TXT button.

Current alpha supports text files up to 8 MiB and rejects common binary/executable formats.
